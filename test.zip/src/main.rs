use std::{
    ffi::OsStr,
    fs::{
        self,
        DirEntry
    },
    io::Error,
    path::Path,
};

use clap::{
    self,
    App,
    Arg,
    ErrorKind
};

fn main() -> Result<(), String> {
    match App::new(clap::crate_name!())
        .version(clap::crate_version!())
        .about(clap::crate_description!())
        .author(clap::crate_authors!())
        .arg(Arg::with_name("dir")
                        .short("d")
                        .long("directory")
                        .takes_value(true)
                        .default_value(".")
        ).arg(Arg::with_name("class")
                        .short("c")
                        .long("class")
                        .takes_value(true)
                        .required(true)
        ).get_matches_safe() {
            Ok(matches) => {
                let path_str = matches.value_of("dir").expect("No directory value specified");
                let path = Path::new(path_str);
                print_entries(&path);
                Ok(())
            },
            Err(err) if err.kind == ErrorKind::HelpDisplayed || err.kind == ErrorKind::VersionDisplayed => {
                err.exit();
            }, 
            Err(dfault) => Err(String::from(dfault.message))
        }
}

fn search(dir: &Path) -> Vec<DirEntry> {
    let mut final_entries = Vec::new();
    let entries = fs::read_dir(dir).expect("Error reading directory").collect::<Result<Vec<_>, Error>>();
    let entries = entries.expect("Error collecting directory entries");
    for entry in entries {
        if entry.metadata().expect("Failed to get metadata").is_dir() {
            final_entries.append(&mut search(entry.path().as_path()));
        } else {
            final_entries.push(entry);
        }
    }

    return final_entries;
}

fn print_entries(dir: &Path) {
    let entries = search(dir);

    let entries = filter_entries_by_extention(entries, OsStr::new("zip"));

    for entry in entries {
        println!("{}", entry.path().to_string_lossy());
    }
}

fn filter_entries_by_extention(entries: Vec<DirEntry>, extension: &OsStr) -> Vec<DirEntry> {
    let mut ret = Vec::new();
    
    for entry in entries {
        if let Some(ext) = entry.path().extension() {
            if ext == extension {
                ret.push(entry);
            }
        }
    }

    return ret;
}
